'use strict';

const expect = require('chai').expect;
const ConvertHandler = require('../controllers/convertHandler.js');

module.exports = function (app) {  

  let convertHandler = new ConvertHandler();

  app.route('/api/convert').get((req,res) => {
    console.log(req.query)
    let input = req.query.input;    
    let initNum = convertHandler.getNum(input);    
    let initUnit = convertHandler.getUnit(input);
    let returnNum = Number(convertHandler.convert(initNum, initUnit));
    let returnUnit = convertHandler.getReturnUnit(initUnit);    
    let string = convertHandler.getString(initNum, initUnit,0,0)
  
  //  if ((initNum == null || initNum == NaN) && initUnit == null){
  // if (isNaN(initNum) && (initUnit == null || returnUnit == null)){
    if (isNaN(initNum) && initUnit == null){
      res.send('invalid number and unit')
    }
    else if (initUnit == null) {    
      res.send('invalid unit')
    }
    //else if (initNum == null || initNum == NaN) {
    else if (isNaN(initNum)) {
      res.send('invalid number')
    }
    else{
      res.send({initNum: initNum, initUnit: initUnit, returnNum: returnNum, returnUnit: returnUnit, string: string})
    }
    
    //res.send(convertHandler.getNum(input))
    //res.send(convertHandler.getUnit(input))
    
  })

};



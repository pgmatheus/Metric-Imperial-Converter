const chai = require('chai');
let assert = chai.assert;
const ConvertHandler = require('../controllers/convertHandler.js');

let convertHandler = new ConvertHandler();

suite('Unit Tests', function(){
  suite('Number verification', function () {
    // 01 
    test('read a whole number input', function(done){
      let input = '10L';          
      assert.equal(10,convertHandler.getNum(input));
      done();      
    })
    // 02 
    test('read a decimal number input', function(done){
      let input = '10.1L';          
      assert.equal(10.1,convertHandler.getNum(input));
      done();      
    })   
    // 03 
    test('read a decimal number input', function(done){
      let input = '10/2L';          
      assert.equal(5,convertHandler.getNum(input));
      done();      
    })   
    // 04 
    test('read a fractional input with a decimal', function(done){
      let input = '10.2/2L';          
      assert.equal(5.1,convertHandler.getNum(input));
      done();      
    })
    // 05
    test('return an error on a double-fraction', function(done){
      let input = '3/2/3';          
      assert.equal(null,convertHandler.getNum(input));
      done();      
    })
    // 06
    test('default to a numerical input of 1 when no numerical input is provided', function(done){
      let input = 'mi';          
      assert.equal(1,convertHandler.getNum(input));
      done();      
    })
    // 07
    test('default to a numerical input of 1 when no numerical input is provided', function(done){
      let input = 'mi';          
      assert.equal(1,convertHandler.getNum(input));
      done();      
    })
  })
  suite('Unit verification', function () {
    // 08
    test('correctly read each valid input unit', function(done){
      let input = '2mi';          
      assert.equal('mi',convertHandler.getUnit(input));
      done(); 
    })
    // 09    
    test('correctly return an error for an invalid input unit', function(done){
      let input = '2mil';          
      assert.equal(null,convertHandler.getUnit(input));
      done(); 
    })
    // 10    
    test('correctly return the spelled-out string unit for each valid input unit', function(done){
      let input = 'mi';          
      assert.equal(' kilometers',convertHandler.spellOutUnit(input));
      done(); 
    })
    // 11    
    test('should correctly convert gal to L', function(done){
      let input1 = 1;
      let input2 = 'gal'          
      assert.equal(3.78541,convertHandler.convert(input1,input2));
      done(); 
    })
    // 12    
    test('should correctly convert L to gal', function(done){
      let input1 = 1;
      let input2 = 'L'          
      assert.equal(0.26417,convertHandler.convert(input1,input2));
      done(); 
    })
    // 13    
    test('should correctly convert mi to km', function(done){
      let input1 = 1;
      let input2 = 'mi'          
      assert.equal(1.60934,convertHandler.convert(input1,input2));
      done(); 
    })
    // 14    
    test('should correctly convert mi to km', function(done){
      let input1 = 1;
      let input2 = 'km'          
      assert.equal(0.62137,convertHandler.convert(input1,input2));
      done(); 
    })
    // 15    
    test('should correctly convert lbs to kg', function(done){
      let input1 = 1;
      let input2 = 'lbs'          
      assert.equal(0.45359,convertHandler.convert(input1,input2));
      done(); 
    })
    // 16    
    test('should correctly convert kg to lbs', function(done){
      let input1 = 1;
      let input2 = 'kg'          
      assert.equal(2.20462,convertHandler.convert(input1,input2));
      done(); 
    })

  })
});
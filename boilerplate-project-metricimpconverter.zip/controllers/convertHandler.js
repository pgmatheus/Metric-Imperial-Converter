function gnum(input) {
  let p = /\//g;
  let regex = /^\d*\.?\d*/;
  let regex2 = /[a-z]+/gi;
  let pp4 = null;
  let pp6 = null;
  
  if (regex2.test(input)){
      let pp = input.match(regex2);
      let pp2 = -pp.join().length;
      pp4 = input.slice(pp2).toLowerCase();
    let pp5 = input.slice(0,input.length+pp2);
    
    if (p.test(pp5)) {
     if (input.match(pp5).length == 1){
       let pnum = pp5.slice(0,pp5.indexOf('/'));
       let segnum = pp5.slice(pp5.indexOf('/')+1);
       pp6 = pnum/segnum;
     }
    } 
    else{          
      if (!isNaN(pp5)){pp6 = pp5;};
      if (pp5 == ""){pp6 = 1;};
    }
  }
  if (pp6 == Infinity){
    pp6 = null;
  }
  if (!isNaN(input)){
    pp6 = input;
  }
  if (!(/^[a-zA-Z]+$/.test(pp4))){
    pp4 = null;
  }
  if (pp4 == 'l'){pp4 = "L"}  
  return [pp6,pp4]
}

function conv(num,und) {
  let ret1vc = 1;
  let ret2ur = null;
  let ret3sr = null;
  let temp = null;
  let ret4sr = null;

  switch (und){
    case 'gal':
      ret1vc = num*3.78541;
      ret2ur = 'L';
      ret3sr = ' liters'
      temp = ' gallons converts to '    
    break;
    case 'L':
      ret1vc = num/3.78541;
      ret2ur = 'gal';
      ret3sr = ' gallons'
      temp = ' liters converts to '    
    break;
    case 'mi':
      ret1vc = num*1.60934;
      ret2ur = 'km';
      ret3sr = ' kilometers'
      temp = ' miles converts to '    
    break;
    case 'km':
      ret1vc = num/1.60934;
      ret2ur = 'mi';
      ret3sr = ' miles'
      temp = ' kilometers converts to '    
    break;
    case 'lbs':
      ret1vc = num*0.453592;
      ret2ur = 'kg';
      ret3sr = ' kilograms'
      temp = ' pounds converts to '    
    break;
    case 'kg':
      ret1vc = num/0.453592;
      ret2ur = 'lbs';
      ret3sr = ' pounds'
      temp = ' kilograms converts to '    
    break;
    default:
    break;

  }

  ret1vc = ret1vc.toFixed(5)
  ret4sr = num + temp + ret1vc + ret3sr
  return [ret1vc,ret2ur,ret3sr,ret4sr]
}

function ConvertHandler() {
  
  this.getNum = function(input) {
    let result = gnum(input);    
    return result[0];
  };
  
  this.getUnit = function(input) {
    let result = gnum(input);
    if (conv(1,result[1])[1] == null) {result[1] = null}
    return result[1];
  };
  
  this.getReturnUnit = function(initUnit) {
    let result = conv(1,initUnit);    
    return result[1];
  };

  this.spellOutUnit = function(unit) {
    let result = conv(1,unit);
    console.log(result[2])    
    return result[2];
  };
  
  this.convert = function(initNum, initUnit) {
    const galToL = 3.78541;
    const lbsToKg = 0.453592;
    const miToKm = 1.60934;
    let result = conv(initNum,initUnit);    
    return result[0];
  };
  
  this.getString = function(initNum, initUnit, returnNum, returnUnit) {
    let result = conv(initNum,initUnit);    
    return result[3];
  };
  
}

module.exports = ConvertHandler;
